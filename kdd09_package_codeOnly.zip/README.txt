This folder contains the following files:

Crawler	: The program used for crawling webpages and generating graph data file.

Code	: The programs for our experiment - inplementation of different algorithms.

