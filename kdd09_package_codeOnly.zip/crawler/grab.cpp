//	grab.cpp
//	To grab a serial of webpages that contains basic information about papers in the database.
// 
//	To control the starting and ending years, change the macro value of START and END.
//		Example: 1991 is 91, 2008 is 8
//	To control the area of the papers, change the url in the program.
//		Example: hep-th is short for High Energy Physics - Theory
//				(See http://arxiv.org for detail.)
//
//	Siyu YANG, Sept. 2008

#include <stdio.h>
#include <stdlib.h>

#define START	91
#define END		8

int main()
{
	int y=START;
	char cmd[200];
	while (y!=END+1) {
		for (int m=1; m<=12; m++)
		{
			sprintf(cmd, "wget http://arxiv.org/list/hep-th/%02d%02d?show=1000 -U NoSuchBrowser/1.0", y, m);
			printf("\n\n\n%s\n", cmd);
			system(cmd);
		}
		y = (y+1)%100;
	}
	return 0;
}
