//	namelist.cpp
//	To get authors' names from the webpages we grabbed, "translate" them into numbers.
// 
//	To control the starting and ending years, change the macro value of START and END.
//		Example: 1991 is 91, 2008 is 8
//	
//	This program will generate two kinds of files:
//	1. namelist.txt
//		This is a list of all author names.
//		Actually, they are urls for searching authors' works. This url is contained in webpages.
//	2. yymm.grp
//		A serial files which are corresponding to the original webpages.
//		A list of the number ID of authors who co-operate in every paper.
//		Every paper is ended with a single line of "-1".
//
//	Siyu YANG, Sept. 2008

#include <stdio.h>
#include <string.h>

#define START	91
#define	END		8
#define LEN 500

FILE *in;
FILE *namelist;
FILE *edges; 

int count=0;
char name[30000][100];

int find(char href[])
{
	for (int i=0; i<count; i++)
		if (strcmp(name[i], href) == 0)
			return i;
	strcpy(name[count], href);
	count++;
	return count-1;
}
 
int main()
{
	char inname[LEN];
	char outname[LEN];
	char buf[LEN];
	char href[LEN];
	int y=START, m;

	while (y!=END+1) {
		for (m=1; m<=12; m++)
		{
			sprintf(inname, "%02d%02d@show=1000", y, m);
			sprintf(outname, "%02d%02d.grp", y, m);
			in = fopen(inname, "r");
			edges = fopen(outname, "w");

			while (!feof(in)) {
				fgets(buf, LEN, in);
				if (strncmp(buf, "<span class=\"descriptor\">Authors:</span> ", 38)==0) {
					int t=0;
					fgets(buf, LEN, in);
					while (strncmp(buf, "</div>", 6) !=0) 
					{
						if (t!=0) 
							fprintf(edges, "%d\n", find(href));

						int e = 9;
						while (buf[e] != '"') 
						{
							href[e-9] = buf[e];
							e++;
						}
						href[e-9] = '\0';

						t++;
						fgets(buf,LEN,in);
					}
					if (t>1) 
						fprintf(edges, "%d\n", find(href));
					fprintf(edges, "-1\n");
				}
			}

			fclose(in);
			fclose(edges);
		}
		y = (y+1)%100;
	}

	namelist = fopen("namelist.txt", "w");
	for (int i=0; i<count; i++)
		fprintf(namelist, "%s\n", name[i]);
	fclose(namelist);
	return 0;
}
