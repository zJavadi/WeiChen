//	edges.cpp
//	To generate a list of edges (pair of nodes).
//	Every edge represents one paper which is co-worked by two specified authors.
// 
//	To control the starting and ending years, change the macro value of START and END.
//		Example: 1991 is 91, 2008 is 8
//	The output file, named "edges.txt"
//		The first line contains two numbers, the number of nodes - n, and the number of edges - m.
//		m lines followed, each line contains two numbers, between 0 and n-1.
//	
//	Siyu YANG, Sept. 2008

#include <stdio.h>
#define START	91
#define END		2

#define LEN		500

FILE* in;
FILE* out;

int main()
{
	int y = START;
	int maxnode = -1; 
	int totedge = 0;

	while (y != END+1) 
	{
		for (int m = 1; m<=12; m++)
		{
			char infile[LEN];
			sprintf(infile, "%02d%02d.grp", y, m);
			in = fopen(infile, "r");

			while (!feof(in)) {
				int c = 0;
				int authors[100];
				int a;
				if (fscanf(in, "%d\n", &a)==EOF)
					break;
				
				while (a>=0) 
				{
					authors[c] = a;
					if (a>maxnode) 
						maxnode = a;
					c++;
					fscanf(in, "%d\n", &a);
				}
				for (int i=0; i<c; i++)
					for (int j=i+1; j<c; j++)
						totedge++;
			}

			fclose(in);
		}
		y = (y+1)%100;
	}

	printf("Total Node = %d\nTotal Edge = %d\n", 1+maxnode, totedge);

	out = fopen("edges.txt", "w");
	y = START;
	fprintf(out, "%d %d\n", maxnode+1, totedge);
	while (y != END+1) 
	{
		for (int m = 1; m<=12; m++)
		{
			char infile[LEN];
			sprintf(infile, "%02d%02d.grp", y, m);
			in = fopen(infile, "r");

			while (!feof(in)) {
				int c = 0;
				int authors[100];
				int a;
				if (fscanf(in, "%d\n", &a)==EOF)
					break;
				
				while (a>=0) 
				{
					authors[c] = a;
					if (a>maxnode) 
						maxnode = a;
					c++;
					fscanf(in, "%d\n", &a);
				}
				for (int i=0; i<c; i++)
					for (int j=i+1; j<c; j++)
					{
						fprintf(out, "%d %d\n", authors[i], authors[j]);
						totedge++;
					}
			}

			fclose(in);
		}
		y = (y+1)%100;
	}
	fclose(out);

	return 0;
}
