//	graph.cpp
//	For Christian, to generate the data file with specified format.
// 
//	It takes "edges.txt" as input, read all edges, sort them, count repeating edges, delete rebundant ones.
//	Output file name: "graph.txt"
//
//	Siyu YANG, Sept. 2008


#include <stdio.h>
#include <string.h>

#define MAX_NODE 30000
#define MAX_EDGE 500000 

struct Edge{
	int u,v,c;
};

int n, m;
Edge edges[MAX_EDGE];


void qsort_edges(int h, int t)
{
	if (h<t) 
	{
		int  i = h, j = t;
		Edge mid = edges[(i+j)/2];
		edges[(i+j)/2] = edges[i];

		while (i<j) 
		{
			while ((i<j) && ((edges[j].u>mid.u)||((edges[j].u==mid.u)&&(edges[j].v>mid.v))))
				j--;
			if (i<j) {
				edges[i] = edges[j];
				i++;
			}
			while ((i<j) && ((edges[i].u<mid.u)||((edges[i].u==mid.u)&&(edges[i].v<mid.v))))
				i++;
			if (i<j) {
				edges[j] = edges[i];
				j--;
			}
		}

		edges[i] = mid;
		qsort_edges(h, i-1);
		qsort_edges(i+1, t);
	}
}

int main()
{
	FILE *in = fopen("edges.txt", "r");
	fscanf(in, "%d %d", &n, &m);	
	for (int i=0; i<m; i++)
	{
		fscanf(in, "%d %d", &edges[i].u, &edges[i].v);
		edges[i+m].u = edges[i].v;
		edges[i+m].v = edges[i].u;
		edges[i].c	 = 1;
		edges[i+m].c = 1;
	}
	fclose(in);

	qsort_edges(0, 2*m-1);

	int m1 = 0;
	for (int i=1; i<2*m; i++)
	{
		if ((edges[i].u != edges[m1].u) || (edges[i].v != edges[m1].v))
		{
			m1++;
			edges[m1] = edges[i];
		}
		else 
		{
			edges[m1].c++;
		}
	}
	if (m!=0)
		m = m1+1;
	
	int line = 0;
	for (int i=0; i<m; i++)
		if (edges[i].u<edges[i].v) 
			line++;

	FILE *out = fopen("graph.txt","w");
	fprintf(out, "sp p %d %d\n", n, line);
	for (int i=0; i<m; i++)
		if (edges[i].u<edges[i].v)
			fprintf(out, "a %d %d %d\n", edges[i].u+1, edges[i].v+1, edges[i].c);
	fclose(out);
	return 0;
}
