#include "setneighbor.h"
#include "graph.h"
#include <stdio.h>
#include <string.h>

int SetNeighbor::n = 0;
int SetNeighbor::list[MAX_NODE] = {0};
char SetNeighbor::file[] = "setneighbor.txt";

void SetNeighbor::Build()
{
	n = Graph::GetN();
	bool d[MAX_NODE];
	bool used[MAX_NODE];
	memset(d, 0, sizeof(bool)*MAX_NODE);
	memset(used, 0, sizeof(bool)*MAX_NODE);
	for (int i=0; i<n; i++)
	{
		int mp = -1, max = -1;
		for (int j=0; j<n; j++)
			if (!used[j]) 
			{
				int t = 0;
				for (int k = 0; k<Graph::GetNeighbor(j); k++)
				{
					int v = Graph::GetEdge(j,k).v;
					if ((!d[v])&&(v!=j)) t++;
				}
				if (!d[j]) t++;

				if (t>max) {
					mp = j;
					max = t;
				}
			}
		used[mp] = true;
		for (int k = 0; k<Graph::GetNeighbor(mp); k++)
		{
			int v = Graph::GetEdge(mp,k).v;
			d[v] = true;
		}
		list[i] = mp;
	}

	FILE *out = fopen(file, "w");
	for (int i=0; i<n; i++)
		fprintf(out, "%d\n", list[i], d[i]);
	fclose(out);
}

void SetNeighbor::BuildFromFile()
{
	n = Graph::GetN();
	FILE* in = fopen(file, "r");
	for (int i=0; i<n; i++)
		fscanf(in, "%ld", &list[i]);
	fclose(in);
}

int SetNeighbor::GetNode(int i)
{
	if (i<0)
		return -1;
	if (i>=n) 
		return -1;
	return list[i];
}


