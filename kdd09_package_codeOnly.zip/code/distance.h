#ifndef DISTANCE_H
#define DISTANCE_H

#include "limit.h"

class Distance
{
private:
	static int n;
	static int d[MAX_NODE];
	static int list[MAX_NODE];
	static char file[STR_LEN];

	static void qsort_distance(int h, int t);
	static int TotalDistance(int node);

public:
	static void Build();
	static void BuildFromFile();
	static int GetNode(int i);
};

#endif

