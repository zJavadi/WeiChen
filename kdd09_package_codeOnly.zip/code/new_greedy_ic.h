#ifndef NEW_GREEDY_IC_H
#define NEW_GREEDY_IC_H

#include "limit.h"

class NewGreedyIC
{
private:
	static int n;
	static int top;
	static double d[MAX_NODE];
	static int list[MAX_NODE];
	static char file[STR_LEN];

public:
	static void Build(int k);
	static void BuildFromFile();
	static int GetNode(int i);
};

#endif

