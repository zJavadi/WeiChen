#ifndef LINEAR_THRESHOLD_H
#define LINEAR_THRESHOLD_H

#include "limit.h"

class LinearThreshold 
{
private:
	static int	n, m;
	static int	targetSize;
	static int	resultSize;
	static int	target[MAX_NODE];
	static bool built;
	
public:
	static void Build();
	static void SetTarget(int size, int set[]);
	static double Run(int num_iter, int size, int set[]);
};

#endif
