#ifndef RANDOM_H
#define RANDOM_H

#include "limit.h"

class Random
{
private:
	static int n;
	static int list[MAX_NODE];
	static char file[STR_LEN];

public:
	static void Build();
	static void BuildFromFile();
	static int  GetNode(int i);	
};

#endif

