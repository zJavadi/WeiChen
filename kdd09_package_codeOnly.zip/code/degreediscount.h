#ifndef DEGREE_DISCOUNT_H
#define DEGREE_DISCOUNT_H

#include "limit.h"

class DegreeDiscount
{
private:
	static int n;
	static int d[MAX_NODE];
	static int list[MAX_NODE];
	static char file[STR_LEN];

//	static void qsort_degree(int h, int t);

public:
	static void Build();
	static void BuildFromFile();
	static int GetNode(int i);
};

#endif

