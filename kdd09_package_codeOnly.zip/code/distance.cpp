#include "distance.h"
#include "graph.h"
#include <stdio.h>
#include <string.h>

int Distance::n = 0;
int Distance::d[MAX_NODE] = {0};
int Distance::list[MAX_NODE] = {0};
char Distance::file[] = "distance.txt";

void Distance::qsort_distance(int h, int t)
{
	if (h<t) 
	{
		int i = h, j = t;
		int midd = d[(i+j)/2];
		int midn = list[(i+j)/2];
		d[(i+j)/2] = d[i];
		list[(i+j)/2] = list[i];

		while (i<j) 
		{
			while ((i<j) && (d[j]>midd))
				j--;
			if (i<j) {
				d[i] = d[j];
				list[i] = list[j];
				i++;
			}
			while ((i<j) && (d[i]<midd))
				i++;
			if (i<j) {
				d[j] = d[i];
				list[j] = list[i];
				j--;
			}
		}

		d[i] = midd;
		list[i] = midn;
		qsort_distance(h, i-1);
		qsort_distance(i+1, t);
	}
}

int Distance::TotalDistance(int node)
{
	// Using Dijkstra
	//printf("Dijkstra %10d\n", node);

	int best[MAX_NODE];
	bool used[MAX_NODE];

	for (int i=0; i<n; i++)
	{
		best[i] = n;
		used[i] = false;
	}
	best[node] = 0;
	
	for (int i=0; i<n; i++)
	{
		int opt = -1;
		for (int j=0; j<n; j++)
			if (!used[j])
				if ((opt==-1) || (best[opt]>best[j]))
					opt = j;

		if (opt<0) break;
		if (best[opt]==n) break;
		used[opt] = true;

		int k = Graph::GetNeighbor(opt);
		for (int j=0; j<k; j++)
		{
			Edge e = Graph::GetEdge(opt, j);
			if (best[e.v]>best[opt]+1)
				best[e.v] = best[opt]+1;
		}
	}
	
	int res = 0;
	for (int i=0; i<n; i++)
		res+=best[i];
	return res;
}

void Distance::Build()
{
	n = Graph::GetN();
	for (int i=0; i<n; i++)
		list[i] = i;
	for (int i=0; i<n; i++)
		d[i] = TotalDistance(i);

	qsort_distance(0, n-1);

	FILE *out = fopen(file, "w");
	for (int i=0; i<n; i++)
		fprintf(out, "%d %d\n", list[i], d[i]);
	fclose(out);
}

void Distance::BuildFromFile()
{
	n = Graph::GetN();
	FILE* in = fopen(file, "r");
	for (int i=0; i<n; i++)
		fscanf(in, "%ld %ld", &list[i], &d[i]);
	fclose(in);
}

int  Distance::GetNode(int i)
{
	if (i<0)
		return -1;
	if (i>=n) 
		return -1;
	return list[i];
}


