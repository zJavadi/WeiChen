#ifndef DEGREE_DISCOUNT_IC_H
#define DEGREE_DISCOUNT_IC_H

#include "limit.h"

class DegreeDiscount_IC
{
private:
	static int n;
	static int d[MAX_NODE];
	static int list[MAX_NODE];
	static char file[STR_LEN];

//	static void qsort_degree(int h, int t);

public:
	static void Build(double ratio);
	static void BuildFromFile();
	static int GetNode(int i);
};

#endif

