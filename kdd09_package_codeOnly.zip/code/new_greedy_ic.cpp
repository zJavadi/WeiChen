#include "limit.h"
#include "new_greedy_ic.h"
#include "graph.h"
#include "rand_graph_ic.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int NewGreedyIC::n = 0;
int NewGreedyIC::top = 0;
double NewGreedyIC::d[MAX_NODE] = {0};
int NewGreedyIC::list[MAX_NODE] = {0};
char NewGreedyIC::file[] = "new_greedy_ic.txt";

void NewGreedyIC::Build(int num)
{
	n = Graph::GetN();
	top = num;

	int set[MAX_NODE];

	for (int i=0; i<top; i++)
	{
		int choice = RandGraphIC::CheckSet(i, set);
		if (choice<0)
			break;

		list[i] = choice;
		d[i] = 0;
		set[i] = choice;
	}

	FILE *out = fopen(file, "w");
	fprintf(out, "%d\n", top);
	for (int i=0; i<top; i++)
		fprintf(out, "%d %Lg\n", list[i], d[i]);
	fclose(out);
}

void NewGreedyIC::BuildFromFile()
{
	n = Graph::GetN();
	FILE* in = fopen(file, "r");
	fscanf(in, "%ld", &top);
	for (int i=0; i<top; i++)
		fscanf(in, "%ld %Lg", &list[i], &d[i]);
	fclose(in);
}

int  NewGreedyIC::GetNode(int i)
{
	if (i<0)
		return -1;
	if (i>=top) 
		return -1;
	return list[i];
}


