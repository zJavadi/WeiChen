#include "limit.h"
#include "graph.h"

#include "random.h"
#include "degree.h"
#include "distance.h"
#include "greedy.h"
#include "setneighbor.h"
#include "degreediscount.h"
#include "degreediscount_ic.h"
#include "new_greedy_wc.h"
#include "new_greedy_ic.h"
#include "mix_greedy_wc.h"
#include "mix_greedy_ic.h"
#include "rand_graph_ic.h"

#include "linear_threshold.h"
#include "independ_cascade.h"
#include "weighted_cascade.h"

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#include <windows.h>


FILE* timetmpfile;
double timer;
LARGE_INTEGER start, end, freq;

void toSimulate(char *file, int (*GetNode)(int i), double (*Run)(int num_iter, int size, int set[]))
{
	FILE *out = fopen(file, "w");
	int set[MAX_NODE];
	for (int t=0; t<SET_SIZE; t++)
	{
		set[t] = GetNode(t);
		fprintf(out, "%02d \t %10Lg\n", t+1, Run(NUM_ITER, t+1, set));
	}
	fclose(out);
}

int main()
{
	srand(time(NULL));
	QueryPerformanceFrequency(&freq);
	system("mkdir tmp");
	
	Graph::Build();
	LinearThreshold::Build();
	WeightedCascade::Build();
	IndependCascade::Build(0.01);

	RandGraphIC::Build();

	// Random
	QueryPerformanceCounter(&start);
	Random::Build();
	QueryPerformanceCounter(&end);
	timer = (double)(end.QuadPart - start.QuadPart) / freq.QuadPart;
	timetmpfile = fopen("time_random.txt", "w");
	fprintf(timetmpfile,"%lg\n", timer);
	fclose(timetmpfile);
	toSimulate("LT_Random.txt", Random::GetNode, LinearThreshold::Run);
	toSimulate("WC_Random.txt", Random::GetNode, WeightedCascade::Run);
	toSimulate("IC_Random.txt", Random::GetNode, IndependCascade::Run);

	// Highest Degree
	QueryPerformanceCounter(&start);
	Degree::Build();
	QueryPerformanceCounter(&end);
	timer = (double)(end.QuadPart - start.QuadPart) / freq.QuadPart;
	timetmpfile = fopen("time_degree.txt", "w");
	fprintf(timetmpfile,"%lg\n", timer);
	fclose(timetmpfile);
	toSimulate("LT_Degree.txt", Degree::GetNode, LinearThreshold::Run);
	toSimulate("WC_Degree.txt", Degree::GetNode, WeightedCascade::Run);
	toSimulate("IC_Degree.txt", Degree::GetNode, IndependCascade::Run);

	// Distance Centrality
	QueryPerformanceCounter(&start);
	Distance::Build();
	QueryPerformanceCounter(&end);
	timer = (double)(end.QuadPart - start.QuadPart) / freq.QuadPart;
	timetmpfile = fopen("time_distance.txt", "w");
	fprintf(timetmpfile,"%lg\n", timer);
	fclose(timetmpfile);
	toSimulate("LT_Distance.txt", Distance::GetNode, LinearThreshold::Run);
	toSimulate("WC_Distance.txt", Distance::GetNode, WeightedCascade::Run);
	toSimulate("IC_Distance.txt", Distance::GetNode, IndependCascade::Run);

	// SingleDiscount
	QueryPerformanceCounter(&start);
	DegreeDiscount::Build();
	QueryPerformanceCounter(&end);
	timer = (double)(end.QuadPart - start.QuadPart) / freq.QuadPart;
	timetmpfile = fopen("time_singlediscount.txt", "w");
	fprintf(timetmpfile,"%lg\n", timer);
	fclose(timetmpfile);
	toSimulate("LT_SingleDiscount.txt", DegreeDiscount::GetNode, LinearThreshold::Run);
	toSimulate("WC_SingleDiscount.txt", DegreeDiscount::GetNode, WeightedCascade::Run);
	toSimulate("IC_SingleDiscount.txt", DegreeDiscount::GetNode, IndependCascade::Run);

	// DegreeDiscountIC
	QueryPerformanceCounter(&start);
	DegreeDiscount_IC::Build(0.01);
	QueryPerformanceCounter(&end);
	timer = (double)(end.QuadPart - start.QuadPart) / freq.QuadPart;
	timetmpfile = fopen("time_degreediscount_ic.txt", "w");
	fprintf(timetmpfile,"%lg\n", timer);
	fclose(timetmpfile);
	toSimulate("LT_DiscountIC.txt", DegreeDiscount_IC::GetNode, LinearThreshold::Run);
	toSimulate("WC_DiscountIC.txt", DegreeDiscount_IC::GetNode, WeightedCascade::Run);
	toSimulate("IC_DiscountIC.txt", DegreeDiscount_IC::GetNode, IndependCascade::Run);

	// GreedyIC (improved by CELF)
	QueryPerformanceCounter(&start);
	Greedy::Build(SET_SIZE,IndependCascade::Run);
	QueryPerformanceCounter(&end);
	timer = (double)(end.QuadPart - start.QuadPart) / freq.QuadPart;
	timetmpfile = fopen("time_greedy_ic.txt", "w");
	fprintf(timetmpfile,"%lg\n", timer);
	fclose(timetmpfile);
	system("copy greedy.txt greedy_ic.txt");
	system("mkdir greedy_ic_tmp");
	system("copy tmp\\* greedy_ic_tmp\\*");
	system("del /Q tmp\\*");
	toSimulate("LT_GreedyIC.txt", Greedy::GetNode, LinearThreshold::Run);
	toSimulate("WC_GreedyIC.txt", Greedy::GetNode, WeightedCascade::Run);
	toSimulate("IC_GreedyIC.txt", Greedy::GetNode, IndependCascade::Run);

	// GreedyWC (improved by CELF)
	QueryPerformanceCounter(&start);
	Greedy::Build(SET_SIZE,WeightedCascade::Run);
	QueryPerformanceCounter(&end);
	timer = (double)(end.QuadPart - start.QuadPart) / freq.QuadPart;
	timetmpfile = fopen("time_greedy_wc.txt", "w");
	fprintf(timetmpfile,"%lg\n", timer);
	fclose(timetmpfile);
	system("copy greedy.txt greedy_wc.txt");
	system("mkdir greedy_wc_tmp");
	system("copy tmp\\* greedy_wc_tmp\\*");
	system("del /Q tmp\\*");
	toSimulate("LT_GreedyWC.txt", Greedy::GetNode, LinearThreshold::Run);
	toSimulate("WC_GreedyWC.txt", Greedy::GetNode, WeightedCascade::Run);
	toSimulate("IC_GreedyWC.txt", Greedy::GetNode, IndependCascade::Run);

	// GreedyLT (improved by CELF)
	QueryPerformanceCounter(&start);
	Greedy::Build(SET_SIZE,LinearThreshold::Run);
	QueryPerformanceCounter(&end);
	timer = (double)(end.QuadPart - start.QuadPart) / freq.QuadPart;
	timetmpfile = fopen("time_greedy_lt.txt", "w");
	fprintf(timetmpfile,"%lg", timer);
	fclose(timetmpfile);
	system("copy greedy.txt greedy_lt.txt");
	system("mkdir greedy_lt_tmp");
	system("copy tmp\\* greedy_lt_tmp\\*");
	system("del /Q tmp\\*");
	toSimulate("LT_GreedyLT.txt", Greedy::GetNode, LinearThreshold::Run);
	toSimulate("WC_GreedyLT.txt", Greedy::GetNode, WeightedCascade::Run);
	toSimulate("IC_GreedyLT.txt", Greedy::GetNode, IndependCascade::Run);

	// MixedGreedyWC
	QueryPerformanceCounter(&start);
	MixGreedyWC::Build();
	QueryPerformanceCounter(&end);
	timer = (double)(end.QuadPart - start.QuadPart) / freq.QuadPart;
	timetmpfile = fopen("time_mix_greedy_wc.txt", "w");
	fprintf(timetmpfile,"%lg\n", timer);
	fclose(timetmpfile);
	system("mkdir mix_greedy_wc_tmp");
	system("copy tmp\\* mix_greedy_wc_tmp\\*");
	system("del /Q tmp\\*");
	toSimulate("LT_MixGreedyWC.txt", MixGreedyWC::GetNode, LinearThreshold::Run);
	toSimulate("WC_MixGreedyWC.txt", MixGreedyWC::GetNode, WeightedCascade::Run);
	toSimulate("IC_MixGreedyWC.txt", MixGreedyWC::GetNode, IndependCascade::Run);

	// NewGreedyWC
	QueryPerformanceCounter(&start);
	NewGreedyWC::Build();
	QueryPerformanceCounter(&end);
	timer = (double)(end.QuadPart - start.QuadPart) / freq.QuadPart;
	timetmpfile = fopen("time_new_greedy_wc.txt", "w");
	fprintf(timetmpfile,"%lg", timer);
	fclose(timetmpfile);
	toSimulate("LT_NewGreedyWC.txt", NewGreedyWC::GetNode, LinearThreshold::Run);
	toSimulate("WC_NewGreedyWC.txt", NewGreedyWC::GetNode, WeightedCascade::Run);
	toSimulate("IC_NewGreedyWC.txt", NewGreedyWC::GetNode, IndependCascade::Run);

	// NewGreedyIC
	QueryPerformanceCounter(&start);
	NewGreedyIC::Build(SET_SIZE);
	QueryPerformanceCounter(&end);
	timer = (double)(end.QuadPart - start.QuadPart) / freq.QuadPart;
	timetmpfile = fopen("time_new_greedy_ic.txt", "w");
	fprintf(timetmpfile,"%lg", timer);
	fclose(timetmpfile);
	toSimulate("LT_NewGreedyIC.txt", NewGreedyIC::GetNode, LinearThreshold::Run);
	toSimulate("WC_NewGreedyIC.txt", NewGreedyIC::GetNode, WeightedCascade::Run);
	toSimulate("IC_NewGreedyIC.txt", NewGreedyIC::GetNode, IndependCascade::Run);

	// MixedGreedyIC
	QueryPerformanceCounter(&start);
	MixGreedyIC::Build(SET_SIZE,IndependCascade::Run);
	QueryPerformanceCounter(&end);
	timer = (double)(end.QuadPart - start.QuadPart) / freq.QuadPart;
	timetmpfile = fopen("time_mix_greedy_ic.txt", "w");
	fprintf(timetmpfile,"%lg\n", timer);
	fclose(timetmpfile);
	system("mkdir mix_greedy_ic_tmp");
	system("copy tmp\\* mix_greedy_ic_tmp\\*");
	system("del /Q tmp\\*");
	toSimulate("LT_MixGreedyIC.txt", MixGreedyIC::GetNode, LinearThreshold::Run);
	toSimulate("WC_MixGreedyIC.txt", MixGreedyIC::GetNode, WeightedCascade::Run);
	toSimulate("IC_MixGreedyIC.txt", MixGreedyIC::GetNode, IndependCascade::Run);

	return 0;
}

