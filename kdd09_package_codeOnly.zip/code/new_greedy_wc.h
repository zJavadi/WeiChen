#ifndef NEW_GREEDY_WC_H
#define NEW_GREEDY_WC_H

#include "limit.h"
#include "graph.h"

struct RandEdge
{
	Edge e;
	bool forward, reverse;
};

class NewGreedyWC
{
	static char file[STR_LEN];

	static int n,m;
	static RandEdge edges[MAX_EDGE];
	static RandEdge myEdges[MAX_EDGE];
	static int seed[MAX_NODE];
	static int index[MAX_NODE];
	static int correspond[MAX_EDGE];

	static int sccN;
	static int sccM;
	static int sccNode[MAX_NODE];
	static int sccEdges[MAX_EDGE];
	static int sccEdgeIdx[MAX_EDGE];
	static int sccIndex[MAX_NODE];
	static bool finish[MAX_NODE];
	static double rank[MAX_NODE];

	static int stackCount;
	static int sccStack[MAX_NODE];

	static void Generate();
	static void qsort_edges(int h, int t);
	static void MinRank(int u);
	static void dfsForward(int r);

public:
	static void Build();
	static int GetNode(int t);
};

#endif

