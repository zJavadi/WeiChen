#ifndef WEIGHTED_CASCADE_H
#define WEIGHTED_CASCADE_H

#include "limit.h"

class WeightedCascade 
{
private:
	static int	n, m;
	static int	targetSize;
	static int	resultSize;
	static int	target[MAX_NODE];
	static bool built;
	
public:
	static void Build();
	static void SetTarget(int size, int set[]);
	static double Run(int num_iter, int size, int set[]);
};

#endif
