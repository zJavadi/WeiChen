#ifndef GRAPH_H
#define GRAPH_H

#include "limit.h"

struct Edge 
{
	int u,v,c;	
};

class Graph
{
private:
	static bool built;
	static int n;
	static int m;
	static int degree[MAX_NODE];
	static int index[MAX_NODE];
	static Edge edges[MAX_EDGE];

	static void qsort_edges(int h, int t);

public:
	static void	Build();
	static int	GetN();
	static int	GetM();
	static int	GetDegree(int node);
	static int	GetNeighbor(int node);
	static Edge	GetEdge(int node, int idx);
};

#endif

