#ifndef SET_NEIGHBOR_H
#define SET_NEIGHBOR_H

#include "limit.h"

class SetNeighbor
{
private:
	static int n;
	static int list[MAX_NODE];
	static char file[STR_LEN];

public:
	static void Build();
	static void BuildFromFile();
	static int GetNode(int i);
};

#endif

