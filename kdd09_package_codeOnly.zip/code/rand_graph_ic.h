#ifndef RAND_GRAPH_IC_H
#define RAND_GRAPH_IC_H

#include "limit.h"
#include "graph.h"

class RandGraphIC
{
	static int n,m;
	static int size;
	static int set[SET_SIZE];
	static Edge edges[MAX_EDGE];
	static Edge myEdges[MAX_EDGE];
	static int index[MAX_NODE];
	static double average_norelate[MAX_NODE];

	static int Check();
	static void Generate();
	static void qsort_edges(int h, int t);

public:
	static void Build();
	static int CheckSet(int s, int *arr);
	static double AveSize(int i);
};

#endif

