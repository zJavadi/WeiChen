#include "rand_graph_ic.h"

#include "limit.h"
#include "graph.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>

int RandGraphIC::n = 0;
int RandGraphIC::m = 0;
int RandGraphIC::size = 0;
int RandGraphIC::set[SET_SIZE] = {0};
Edge RandGraphIC::edges[MAX_EDGE];
Edge RandGraphIC::myEdges[MAX_EDGE];
int RandGraphIC::index[MAX_NODE];
double RandGraphIC::average_norelate[MAX_NODE];

void RandGraphIC::Build()
{
	Graph::Build();
	n = Graph::GetN();
	m = Graph::GetM();
	int count = 0;
	for (int i=0; i<n; i++)
		for (int j=0; j<Graph::GetNeighbor(i); j++)
		{
			edges[count] = Graph::GetEdge(i,j);
			count++;
		}
	assert(m==count);
}

int RandGraphIC::CheckSet(int s, int *arr)
{
	size = s;
	for (int i=0; i<s; i++)
		set[i] = arr[i];
	return Check();
}

void RandGraphIC::qsort_edges(int h, int t)
{
	if (h<t) 
	{
		int  i = h, j = t;
		Edge mid = myEdges[(i+j)/2];
		myEdges[(i+j)/2] = myEdges[i];

		while (i<j) 
		{
			while ((i<j) && ((myEdges[j].u>mid.u)||((myEdges[j].u==mid.u)&&(myEdges[j].v>mid.v))))
				j--;
			if (i<j) {
				myEdges[i] = myEdges[j];
				i++;
			}
			while ((i<j) && ((myEdges[i].u<mid.u)||((myEdges[i].u==mid.u)&&(myEdges[i].v<mid.v))))
				i++;
			if (i<j) {
				myEdges[j] = myEdges[i];
				j--;
			}
		}

		myEdges[i] = mid;
		qsort_edges(h, i-1);
		qsort_edges(i+1, t);
	}
}

void RandGraphIC::Generate()
{
	int mm = 0;
	for (int i=0; i<m; i++)
		if (edges[i].u<edges[i].v)
		{
			for (int j=0; j<edges[i].c; j++)
				if ((double)rand()/(double)RAND_MAX < 0.01)
				{
					myEdges[mm] = edges[i];
					myEdges[mm+1].u = edges[i].v;
					myEdges[mm+1].v = edges[i].u;
					myEdges[mm+1].c = edges[i].c;
					mm+=2;
					break;
				}
		}
	qsort_edges(0, mm-1);

	for (int i=0; i<n; i++)
		index[i] = -1;
	for (int i=0; i<mm; i++)
		index[myEdges[i].u] = i;
	for (int i=0; i<n; i++)
		if (i!=0)
		{
			if ((index[i] < 0) && (index[i-1]>=0))
				index[i] = index[i-1];
		}
}

int RandGraphIC::Check()
{
	int component[MAX_NODE];
	int compsize[MAX_NODE];
	const int TIME = NUM_ITER;

	memset(average_norelate, 0, sizeof(double)*MAX_NODE);

	for (int zz = 0; zz < TIME; zz++)
	{
		Generate();

		memset(component, 0, sizeof(int)*MAX_NODE);
		int count = 0;
		for (int i=0; i<n; i++)
			if (component[i] == 0)
			{
				count++;
				component[i] = count;

				static int list[MAX_NODE];
				int h, t;
				list[0] = i;
				h = 0; t = 1;
				while (h<t)
				{
					int a, b = index[list[h]]+1;
					if (list[h] == 0) a = 0;
					else a = index[list[h]-1]+1;
					for (int j=a; j<b; j++)
					{
						if (component[myEdges[j].v] == 0)
						{
							component[myEdges[j].v] = count;
							list[t] = myEdges[j].v;
							t++;
						}
						else 
						{
							assert(component[myEdges[j].v] == count);
						}
					}
					h++;
				}
				compsize[count] = t;
			}

		for (int i=0; i<n; i++)
		{
			bool related = false;
			for (int j=0; j<size; j++)
				if (component[i] == component[set[j]])
				{
					related = true;
					break;
				}
			if (!related)
				average_norelate[i] += (double) compsize[component[i]];
		}
	}

	double max = -1;
	int choice = -1;
	for (int i=0; i<n; i++)
		if (average_norelate[i]>max)
		{
			max = average_norelate[i];
			choice = i;
		}
	return choice;
}

double RandGraphIC::AveSize(int i)
{
	return average_norelate[i]/(double)NUM_ITER;
}