#include "new_greedy_wc.h"
#include "limit.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <assert.h>

char NewGreedyWC::file[] = "new_greedy_wc.txt";

int NewGreedyWC::n = 0;
int NewGreedyWC::m = 0;
RandEdge NewGreedyWC::edges[MAX_EDGE];
RandEdge NewGreedyWC::myEdges[MAX_EDGE];
int NewGreedyWC::seed[MAX_NODE];
int NewGreedyWC::index[MAX_NODE];

int NewGreedyWC::sccN = 0;
int NewGreedyWC::sccM = 0;
int NewGreedyWC::sccNode[MAX_NODE];
int NewGreedyWC::sccEdges[MAX_EDGE];
int NewGreedyWC::sccEdgeIdx[MAX_EDGE];
int NewGreedyWC::sccIndex[MAX_NODE];
bool NewGreedyWC::finish[MAX_NODE];
double NewGreedyWC::rank[MAX_NODE];

int NewGreedyWC::stackCount;
int NewGreedyWC::sccStack[MAX_NODE];
int NewGreedyWC::correspond[MAX_EDGE];

void NewGreedyWC::Build()
{
	Graph::Build();
	n = Graph::GetN();
	int mm = 0;
	for (int i=0; i<n; i++)
		for (int j=0; j<Graph::GetNeighbor(i); j++)
		{
			Edge e = Graph::GetEdge(i,j);
			if (e.u < e.v)
			{
				edges[mm].e = e;
				edges[mm+1].e.c = e.c;
				edges[mm+1].e.u = e.v;
				edges[mm+1].e.v = e.u;
				correspond[mm] = mm+1;
				correspond[mm+1] = mm;
				edges[mm].forward = false;
				edges[mm+1].forward = false;
				edges[mm].reverse = false;
				edges[mm+1].reverse = false;
				mm+=2;
			}
		}
	qsort_edges(0, mm-1);
	m = mm;

	bool used[MAX_NODE];
	memset(used, 0, sizeof(bool)*MAX_NODE);

	static double contribute[MAX_NODE];
	static double contri1[MAX_NODE];
	static int list[MAX_NODE];
	static int zero[MAX_NODE];
	for (int zz=0; zz<SET_SIZE; zz++)
	{
		memset(contribute, 0, sizeof(double)*MAX_NODE);
		memset(zero, 0, sizeof(int)*MAX_NODE);
		
		for (int yy=0; yy<NUM_ITER; yy++)
		{
			Generate();

			memset(contri1, 0, sizeof(double)*MAX_NODE);
			for (int xx = 0; xx < 5; xx++)
			{
				memset(finish, 0, sizeof(bool)*MAX_NODE);
			
				for (int i=0; i<sccN; i++)
					rank[i] = -log(1.0-(double)rand()/(double)RAND_MAX)/(double)sccIndex[i];

				for (int i=0; i<sccN; i++)
					if (!finish[i])
					{
						MinRank(i);
						finish[i] = true;
					}

				double minS = 10E100;
				for (int i=0; i<n; i++)
					if (used[i])
					{
						if (minS>rank[sccNode[i]])
							minS = rank[sccNode[i]];
					}
	
				for (int i=0; i<n; i++)
					if (minS>rank[sccNode[i]])
						contri1[i]+=rank[sccNode[i]];
					else
						contri1[i]+=minS;
			}

			for (int i=0; i<n; i++)
				contribute[i]+=(double)4.0/contri1[i];
		}
		
		double max = -1.0;
		for (int i=0; i<n; i++)
			if ((!used[i]) && (zero[i] < NUM_ITER))
			{
//				double t = (double)(NUM_ITER-zero[i])*(double)(NUM_ITER-zero[i])/(double)NUM_ITER/contribute[i];
				double t = contribute[i]/(double)NUM_ITER;
				if (t > max)
				{
					max = t;
					seed[zz] = i;
				}
			}
		used[seed[zz]] = true;
		//printf("%d %d\n", zz, seed[zz]);
	}

	FILE *out = fopen(file, "w");
	for (int i=0; i<SET_SIZE; i++)
		fprintf(out,"%d\n", seed[i]);
	fclose(out);
}

void NewGreedyWC::MinRank(int u)
{
	if (finish[u]) return;
	for (int i=sccEdgeIdx[u]; i<sccEdgeIdx[u+1]; i++)
	{
		MinRank(sccEdges[i]);
		if ((rank[sccEdges[i]]<rank[u]))
			rank[u] = rank[sccEdges[i]];
	}
	finish[u] = true;
}

int NewGreedyWC::GetNode(int t)
{
	return seed[t];
}

void NewGreedyWC::qsort_edges(int h, int t)
{
	if (h<t) 
	{
		int  i = h, j = t;
		RandEdge mid = edges[(i+j)/2];
		int midc = correspond[(i+j)/2];
		edges[(i+j)/2] = edges[i];
		if (midc != i)
		{
			correspond[correspond[i]] = (i+j)/2;
			correspond[(i+j)/2] = correspond[i];
		}
		else
			midc = (i+j)/2;

		while (i<j) 
		{
			while ((i<j) && ((edges[j].e.u>mid.e.u)||((edges[j].e.u==mid.e.u)&&(edges[j].e.v>mid.e.v))))
				j--;
			if (i<j) {
				edges[i] = edges[j];
				if (j!=midc)
				{
					correspond[i] = correspond[j];
					correspond[correspond[j]] = i;
				}
				else 
					midc = i;
				i++;
			}
			while ((i<j) && ((edges[i].e.u<mid.e.u)||((edges[i].e.u==mid.e.u)&&(edges[i].e.v<mid.e.v))))
				i++;
			if (i<j) {
				edges[j] = edges[i];
				if (i!=midc) {
					correspond[j] = correspond[i];
					correspond[correspond[i]] = j;
				}
				else
					midc = j;
				j--;
			}
		}

		edges[i] = mid;
		correspond[i] = midc;
		correspond[midc] = i;
		qsort_edges(h, i-1);
		qsort_edges(i+1, t);
	}
}

void NewGreedyWC::dfsForward(int r)
{
	int a = 0;
	if (r != 0)
		a = index[r-1]+1;
	for (int i=a; i<=index[r]; i++)
		if (myEdges[i].forward)
			if (sccNode[myEdges[i].e.v] == 0)
			{
				sccNode[myEdges[i].e.v] = -1;
				dfsForward(myEdges[i].e.v);
			}

	sccStack[stackCount] = r;
	stackCount++;
}

void NewGreedyWC::Generate()
{
	for (int i=0; i<m; i++)
	{
		edges[i].forward = false;
		edges[correspond[i]].reverse = false;
		for (int j=0; j<edges[i].e.c; j++)
			if ((double)rand()/(double)RAND_MAX < (double)1/(double)Graph::GetDegree(edges[i].e.v))
			{
				edges[i].forward = true;
				edges[correspond[i]].reverse = true;
				break;
			}
	}

	int mm=0;
	for (int i=0; i<m; i++)
		if (edges[i].forward || edges[i].reverse)
		{
			myEdges[mm] = edges[i];
			mm++;
		}
	for (int i=0; i<n; i++)
		index[i] = -1;
	for (int i=0; i<mm; i++)
		index[myEdges[i].e.u] = i;
	for (int i=0; i<n; i++)
		if (i!=0)
		{
			if (index[i] < 0)
				index[i] = index[i-1];
		}

	stackCount = 0;
	memset(sccNode, 0, sizeof(int)*MAX_NODE);
	for (int i=0; i<n; i++)
		if (sccNode[i] == 0)
		{
			sccNode[i] = -1;
			dfsForward(i);
		}

	int sccList[MAX_NODE];
	sccN = 0;
	sccIndex[0] = 0;
	int listH = 0, listT = 0;
	for (int i=stackCount-1; i>=0; i--)
		if (sccNode[sccStack[i]] < 0)
		{
			sccNode[sccStack[i]] = sccN;
			sccList[listT] = sccStack[i];
			listT++;

			while (listH<listT)
			{
				int a = 0;
				if (sccList[listH] != 0)
					a = index[sccList[listH]-1]+1;
				for (int j=a; j<=index[sccList[listH]]; j++)
					if ((myEdges[j].reverse) && (sccNode[myEdges[j].e.v]<0))
					{
						sccNode[myEdges[j].e.v] = sccN;
						sccList[listT] = myEdges[j].e.v;
						listT++;
					}
				listH++;
			}

			sccN++;
			sccIndex[sccN] = listT;
		}
	
	sccM = 0;
	memset(sccEdgeIdx, 0, sizeof(int)*MAX_NODE);
	for (int i=0; i<sccN; i++)
	{
		for (int j=sccIndex[i]; j<sccIndex[i+1]; j++)
		{
			int s=sccList[j];
			int a = 0;
			if (s != 0)
				a = index[s-1]+1;
			for (int l=a; l<=index[s]; l++)
			{
				if ((sccNode[myEdges[l].e.v]!=i) && 
					(myEdges[l].forward))
				{
					sccEdges[sccM] = sccNode[myEdges[l].e.v];
					sccM++;
				}
			}
		}
		sccEdgeIdx[i+1] = sccM;
	}

	for (int i=0; i<sccN; i++)
		sccIndex[i] = sccIndex[i+1]-sccIndex[i];
}

