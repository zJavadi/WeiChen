#ifndef LIMIT_H
#define LIMIT_H

#define MAX_NODE	40000
#define	MAX_EDGE	500000

#define STR_LEN		200

#define NUM_ITER	20000
#define SET_SIZE	50

#endif
