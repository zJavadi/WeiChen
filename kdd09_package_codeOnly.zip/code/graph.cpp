#include "graph.h"
#include <stdio.h>
#include <string.h>

bool Graph::built = false;
int  Graph::n = 0;
int  Graph::m = 0;
int  Graph::index[MAX_NODE] = {0};
int  Graph::degree[MAX_NODE] = {0};
Edge Graph::edges[MAX_EDGE];

void Graph::qsort_edges(int h, int t)
{
	if (h<t) 
	{
		int i = h, j = t;
		Edge mid = edges[(i+j)/2];
		edges[(i+j)/2] = edges[i];

		while (i<j) 
		{
			while ((i<j) && ((edges[j].u>mid.u)||((edges[j].u==mid.u)&&(edges[j].v>mid.v))))
				j--;
			if (i<j) {
				edges[i] = edges[j];
				i++;
			}
			while ((i<j) && ((edges[i].u<mid.u)||((edges[i].u==mid.u)&&(edges[i].v<mid.v))))
				i++;
			if (i<j) {
				edges[j] = edges[i];
				j--;
			}
		}

		edges[i] = mid;
		qsort_edges(h, i-1);
		qsort_edges(i+1, t);
	}
}

void Graph::Build()
{
	if (built) 
		return;
	built = true;

	memset(degree, 0, sizeof(int)*MAX_NODE);

	scanf("%ld %ld", &n, &m);	
	for (int i=0; i<m; i++)
	{
		scanf("%ld %ld", &edges[i].u, &edges[i].v);
		edges[i+m].u = edges[i].v;
		edges[i+m].v = edges[i].u;
		edges[i].c	 = 1;
		edges[i+m].c = 1;
		degree[edges[i].u]++;
		degree[edges[i].v]++;
	}

	qsort_edges(0, 2*m-1);

	int m1 = 0;
	for (int i=1; i<2*m; i++)
	{
		if ((edges[i].u != edges[m1].u) || (edges[i].v != edges[m1].v))
		{
			m1++;
			edges[m1] = edges[i];
		}
		else 
		{
			edges[m1].c++;
		}
	}
	if (m!=0)
		m = m1+1;
	
	for (int i=0; i<n; i++)
		index[i] = 0;
	for (int i=0; i<m; i++)
		index[edges[i].u] = i;
	for (int i=1; i<n; i++)
		if (index[i] < index[i-1])
			index[i] = index[i-1];
}

int Graph::GetN()
{
	if (!built)	Build();
	return n;
}

int Graph::GetM()
{
	if (!built)	Build();
	return m;
}

int Graph::GetDegree(int node)
{
	if (!built)	Build();
	return degree[node];
}

int Graph::GetNeighbor(int node)
{
	if (!built)	Build();
	if (node == 0)
		return index[node]+1;
	else 
		return index[node]-index[node-1];
}

Edge Graph::GetEdge(int node, int idx)
{
	if (!built)	Build();
	if (node == 0)
		return edges[idx];
	else
		return edges[index[node-1]+1+idx];
}

