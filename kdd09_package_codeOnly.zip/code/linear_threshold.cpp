#include "graph.h"
#include "linear_threshold.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>

int LinearThreshold::n = 0;
int LinearThreshold::m = 0;
int	LinearThreshold::targetSize = 0;
int	LinearThreshold::resultSize = 0;
int	LinearThreshold::target[MAX_NODE] = {0};
bool LinearThreshold::built = false;

void LinearThreshold::Build()
{
	n = Graph::GetN();
	m = Graph::GetM();
	built = true;
}

void LinearThreshold::SetTarget(int size, int set[])
{
	if (!built) Build();
	targetSize = size;
	for (int i=0; i<size; i++)
		target[i] = set[i];
	resultSize = 0;
}

double LinearThreshold::Run(int num_iter, int size, int set[])
{
	SetTarget(size, set);

//	printf("hi -1\n");

	int		h, t;
	int		list[MAX_NODE];
//	bool	active[MAX_NODE];
	static double	theta[MAX_NODE];

	for (int it=0; it<num_iter; it++)
	{
//		printf("%d\n", it);
//		memset(active, 0, sizeof(bool)*MAX_NODE);
		for (int i=0; i<n; i++)
			theta[i] = 2.0;

		for (int i=0; i<targetSize; i++) 
		{
			list[i] = target[i];
			theta[target[i]] = -1.0;
//			active[target[i]] = true;
		}
		resultSize += targetSize;

		h = 0;
		t = targetSize;

		while (h<t) 
		{
			int k = Graph::GetNeighbor(list[h]);
			for (int i=0; i<k; i++)
			{
				Edge e = Graph::GetEdge(list[h], i);
				if (theta[e.v]<0) continue;
				if (theta[e.v]>1.5)
					theta[e.v] = (double)rand()/(double)RAND_MAX;
				theta[e.v] -= (double)e.c/(double)Graph::GetDegree(e.v);
				if (theta[e.v]<0)
				{
					list[t] = e.v;
					//active[e.v] = true;
					t++;
					resultSize++;
				}
			}
			h++;
		}
	}
//	printf("bye\n");
//	printf("%lg\n", (double)resultSize / (double)num_iter);
	return (double)resultSize / (double)num_iter;
}
